# Detección de fraude en tarjetas de crédito (Databricks)

> **Esqueleto.** Sustituye esta carpeta por tu proyecto actual. Los estudiantes ven esta carpeta en Databricks: nada que apunte a material privado puede aparecer aquí.

Proyecto de referencia: arquitectura Medallion con Delta Live Tables, *feature store*, experimentación con MLflow, ciclo champion-challenger, inferencia batch y monitorización con Lakehouse Monitoring.

## Estructura prevista

    code/
    ├── README.md
    ├── LICENSE
    ├── pyproject.toml
    ├── config/                      # Configuración centralizada
    ├── src/medallion_pipeline/transformations/
    ├── notebooks/
    ├── alerts/
    └── resources/

## Convenciones

Código, comentarios y mensajes de commit en inglés; documentación en español. Commits siguiendo Conventional Commits.
